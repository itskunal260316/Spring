package com.lti.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.dao.GenericRepository;
import com.lti.dto.ShoppingDTO;
import com.lti.entity.Product;
import com.lti.service.ShoppingService;

public class ShoppingTest {

	@Test
	public void addSomeProducts() {
		Product product = new Product();
		product.setName("iPhone");
		product.setPrice(35000);
		product.setStock(99);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("shopping-config.xml");
		GenericRepository repo = context.getBean(GenericRepository.class);
		repo.store(product);
	}
	
	@Test
	public void placeOrder() {
		System.out.println("placing order");
		ShoppingDTO dto = new ShoppingDTO();
		dto.setProductId(81);
		dto.setPaymentMode("Credit card");
		dto.setQuantity(2);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("shopping-config.xml");
		ShoppingService ss=context.getBean(ShoppingService.class);
		ss.placeOrder(dto);
	}
	
	
}
