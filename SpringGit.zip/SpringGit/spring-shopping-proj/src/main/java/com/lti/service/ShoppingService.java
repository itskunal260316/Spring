package com.lti.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.dao.GenericRepository;
import com.lti.dto.ShoppingDTO;
import com.lti.entity.Order;
import com.lti.entity.Payment;
import com.lti.entity.Product;

//@Component
@Service //same as @Component
public class ShoppingService {
	
	@Autowired
	private GenericRepository genericRepository;
	
	@Transactional
	public void placeOrder(ShoppingDTO shoppingDTO) {
		Product product = 
				genericRepository.fetchById(Product.class, shoppingDTO.getProductId());
		System.out.println("price : "+ product.getPrice()+" " +shoppingDTO.getQuantity());
		double totalAmount = product.getPrice() * shoppingDTO.getQuantity();
		System.out.println("calculated amount");
		
		Order order = new Order();
		order.setAmount(totalAmount);
		order.setOrderDate(new Date());
		genericRepository.store(order);
		
		Payment payment = new Payment();
		payment.setAmount(totalAmount);
		payment.setMode(shoppingDTO.getPaymentMode());
		genericRepository.store(payment);
		
		product.setStock(product.getStock() - shoppingDTO.getQuantity());
		genericRepository.store(product);
		
	}
}
