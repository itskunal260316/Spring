package com.lti.dao;

import java.io.PrintWriter;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("GenericDao") //@Repository is a type of @Component used for Dao class(for jdbc)
//persistence logic(logic to persist the data in the database)
public class GenericRepository {
	
	@PersistenceContext
	protected EntityManager entityManager;
	
	@Transactional // provides begin() and commit() methods of hibernate
	public void store(Object obj) {
		entityManager.merge(obj);
	}
	
	public <E> E fetchById(Class<E> classname,int pk) {
		
		E e=entityManager.find(classname, pk);
		return e;

	}

	public <E> List<?> fetchAll(Class<E> clazz) {
	
		Query q = entityManager.createQuery("select obj from" + clazz.getName() + " as obj");
		return q.getResultList();

	}

}
