package com.lti.component;

public interface SpellCheckInterface {
	
	public void checkSpellingMistakes(String document);

}
