package com.lti.component;

public interface Calc {
	
	public int add(int x,int y);

}
