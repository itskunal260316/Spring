package com.lti.component;

public interface TextEditorInterface {

	public void loadTextDocument(String document);
	

}