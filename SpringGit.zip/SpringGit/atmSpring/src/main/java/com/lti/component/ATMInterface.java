package com.lti.component;

public interface ATMInterface {

	void withdraw(String atmid, int acno, double amount);

}