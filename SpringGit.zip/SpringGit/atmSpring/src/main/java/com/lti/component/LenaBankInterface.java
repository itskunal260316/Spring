package com.lti.component;

public interface LenaBankInterface {

	void accessBank(String data);

}