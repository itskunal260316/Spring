package com.lti.component;

public class LenaBank implements LenaBankInterface {
	
	/* (non-Javadoc)
	 * @see com.lti.component.LenaBankInterface#accessBank(java.lang.String)
	 */
	public void accessBank(String data) {
		System.out.println("Acess data from the Bank");
	}

}
