package com.lti.component;

public interface ATMBalance {

	void checkBalance(String atmid, int acno, double balance);

}