package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.lti.entity.CarPartsDao;

@Component("carPartsDao3")
public class CarPartsDaoImpl3 implements CarPartsDao {

	//thats our dependency in this example
	@Autowired
private DataSource dataSource; 

	public void addNewPart(CarPart carPart) {
	
		//////here we have used JdbcTemplate instead of JDBC or DataSource
		JdbcTemplate jt = new JdbcTemplate(dataSource);
		
		System.out.println("Connected....");
		jt.update("insert into tbl_carparts values(?,?,?,?,?)",
	
			
			carPart.getPartNo(),
			carPart.getName(),
			carPart.getCarModel(),
			 carPart.getPrice(),
			carPart.getQuantity());
			

			System.out.println("Data inserted");

		} 
				
	@Override
	public List<CarPart> getAvailableParts() {

		Connection conn = null;
		PreparedStatement ps1 = null; // pre compiled sql statement
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hr");
			System.out.println("Connected....");
			ps1 = conn.prepareStatement("select * from tbl_carparts");
			rs = ps1.executeQuery();

			List<CarPart> parts = new ArrayList<CarPart>();
			while (rs.next()) {

				CarPart part = new CarPart();
				part.setPartNo(rs.getInt(1));
				part.setName(rs.getString(2));
				part.setCarModel(rs.getString(3));
				part.setPrice(rs.getDouble(4));
				part.setQuantity(rs.getInt(5));
				parts.add(part);

			}
			return parts;

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				ps1.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;

	}

}
