package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.lti.entity.CarPartsDao;

@Component("carPartsDao4")
public class CarPartsDaoImpl4 implements CarPartsDao {

	// @Autowired -- Autowired annotation doesnt work in case of injecting
	// EntityManager object thats why we are using PersistenceContext
	@PersistenceContext
	private EntityManager entityManager;

	@Transactional // provides begin() and commit() methods of hibernate
	public void addNewPart(CarPart carPart) {
		entityManager.persist(carPart);
	}

	@Override
	public List<CarPart> getAvailableParts() {

		Query q = entityManager.createQuery("select carpart from CarPart as carpart");
		return q.getResultList();

	}

}
