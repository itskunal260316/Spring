package com.lti.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.lti.entity.CarPartsDao;

@Component("carPartsDao2")
public class CarPartsDaoImpl2 implements CarPartsDao {

	//thats our dependency in this example
	@Autowired
private DataSource dataSource; 

@Override
	public void addNewPart(CarPart carPart) {

		//////here we are using DataSource instead of JDBC
		Connection con = null;
		PreparedStatement ps = null; // pre compiled sql statement

		try {
			
			
			con = dataSource.getConnection();
			System.out.println("Connected....");

			ps = con.prepareStatement("insert into tbl_carparts values(?,?,?,?,?)");
			ps.setInt(1, carPart.getPartNo());
			ps.setString(2, carPart.getName());
			ps.setString(3, carPart.getCarModel());
			ps.setDouble(4, carPart.getPrice());
			ps.setInt(5, carPart.getQuantity());
			ps.executeUpdate();

			System.out.println("Data inserted");

		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {

				ps.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public List<CarPart> getAvailableParts() {

		JdbcTemplate jt=new JdbcTemplate();
		List<CarPart> list=jt.query("select *from tbl_carparts",new CarPartRowMapper()); 
		//object of class which is implementing RowMapper => new CarPartRowMapper()
		return list;
			}
	
	class CarPartRowMapper implements RowMapper<CarPart>{
		@Override
		public CarPart mapRow(ResultSet rs,int index) throws SQLException{
			CarPart part = new CarPart();
			part.setPartNo(rs.getInt(1));
			part.setName(rs.getString(2));
			part.setCarModel(rs.getString(3));
			part.setPrice(rs.getDouble(4));
			part.setQuantity(rs.getInt(5));
			
			return part;
		}
	}

}
