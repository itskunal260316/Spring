package com.lti.carParts.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.dao.CarPart;
import com.lti.entity.CarPartsDao;

public class TestCarParts {
	
	public static void main(String[] args) {
		//loading IoC container
		ApplicationContext context = new ClassPathXmlApplicationContext("carparts-config.xml");
		//context communicates with container
		
		//Accessing one of the bean
		CarPartsDao dao = (CarPartsDao)context.getBean("carPartsDao3");// this is only a ref of the interface
		CarPart part = new CarPart();
		part.setPartNo(4);
		part.setName("Nut and Bolts");
		part.setCarModel("VW Polo");
		part.setPrice(455);
		part.setQuantity(10);
		dao.addNewPart(part);
		
	}

	
}
